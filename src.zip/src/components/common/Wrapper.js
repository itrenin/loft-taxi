import React from 'react'
import Background from './Background'

const Wrapper = ({ children }) => <Background>{children}</Background>

export default Wrapper
