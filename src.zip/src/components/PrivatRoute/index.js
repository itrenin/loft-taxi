export { default } from './PrivatRoute'
